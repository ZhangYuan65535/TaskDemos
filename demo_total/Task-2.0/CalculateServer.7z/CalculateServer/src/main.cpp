#include "calculatesys.h"
#include "primecalcsub.h"
#include "testwidget.h"
#include "testplugin.h"
#include <QApplication>
#include <QDebug>
#include <QSharedPointer>

int main(int argc,char **argv)
{
    QApplication app(argc,argv);

//    TestWidget t;
//    t.show();
    TestPlugin t;


    return app.exec();
}
