#include "calcbase.h"

CalcBase::CalcBase(QObject *parent) :
    QObject(parent)
{

}

CalcBase::~CalcBase()
{

}
