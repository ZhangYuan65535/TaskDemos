#ifndef CALCULATESYS_H
#define CALCULATESYS_H

#include <QObject>

class CalculateSys : public QObject
{
    Q_OBJECT
public:
    explicit CalculateSys(QObject *parent = nullptr);

private:
};

#endif // CALCULATESYS_H
