#include "calculatesys.h"

CalculateSys::CalculateSys(QObject *parent) :
    QObject(parent)
{

}
