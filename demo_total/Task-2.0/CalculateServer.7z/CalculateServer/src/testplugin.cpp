#include "testplugin.h"
#include <QDebug>
#include <QLineEdit>
#include <QLabel>
#include <QPushButton>
#include <QGridLayout>
#include <QMessageBox>
#include <QDir>
#include <QPluginLoader>
#include <QApplication>

TestPlugin::TestPlugin(QObject *parent):
    QObject(parent)
{
    if (!loadPlugin())
    {
        qWarning()<<"加载插件失败";
    }
}

bool TestPlugin::loadPlugin()
{
    bool ret = true;
    //获取当前应用程序所在路径，此处默认使用的是 Linux 系统。
    QDir pluginsDir(qApp->applicationDirPath());
    //切换到插件目录
    pluginsDir.cd("plugin");
    //遍历plugins目录下所有文件
    foreach (QString fileName, pluginsDir.entryList(QDir::Files))
    {
        QPluginLoader pluginLoader(pluginsDir.absoluteFilePath(fileName));
        QObject *plugin = pluginLoader.instance();
        qWarning()<<fileName<<":"<<plugin;
        if (plugin)
        {
            //插件名称
            QString pluginName = plugin->metaObject()->className();
//            //对插件初始化
//            if(pluginName == "EchoPlugin")
//            {
//                echoInterface = qobject_cast<EchoInterface*>(plugin);
//                if (echoInterface)
//                    ret =  true;
//                break;
//            }
//            else
//            {
//                ret = false;
//            }
        }
    }
    return ret;
}
