#ifndef TESTPLUGIN_H
#define TESTPLUGIN_H

#include "wininterface.h"
#include <QObject>

class TestPlugin:public QObject
{
    Q_OBJECT
public:
    TestPlugin(QObject *parent = nullptr);
    bool loadPlugin();
    WinInterface *winInterface;
};

#endif // TESTPLUGIN_H
