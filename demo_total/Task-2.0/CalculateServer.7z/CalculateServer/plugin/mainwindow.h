#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>

class MainWindow:public QWidget
{
public:
    MainWindow(QWidget *parent = nullptr);
};

#endif // MAINWINDOW_H
