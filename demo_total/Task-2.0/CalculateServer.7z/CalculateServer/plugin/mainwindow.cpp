#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent):
    QWidget(parent)
{

}
