#ifndef WINPLUGIN_H
#define WINPLUGIN_H

#include "../src/wininterface.h"
#include <QObject>

class WinPlugin:public QObject,public WinInterface
{
    Q_OBJECT
    Q_PLUGIN_METADATA(IID WinInterface_iid)
    Q_INTERFACES(WinInterface)
public:
    explicit WinPlugin(QObject *parent = 0);
};

#endif // WINPLUGIN_H
