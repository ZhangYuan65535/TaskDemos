#include "winplugin.h"
#include "mainwindow.h"

WinPlugin::WinPlugin(QObject *parent):
    QObject(parent)
{
    MainWindow m;
    m.show();
    while(1)
    {

    }
}
